# זיהוי תנועת מטופל ממצלמת הקשת ARC22: סיכום בעברית

המסמך המלא (באנגלית) הוא `README.md`. כאן סיכום קצר ומפת דרכים. מצגת (אנגלית, 26 שקפים): https://claude.ai/artifact/F8khHgMArTEGyJ4Ub6o1Ho

## מה בחבילה
- `code/`: הקוד (`motion/` הספרייה, `scripts/` הסקריפטים, `data/` כיול, מודל הקשת, אזור הגלאי ותמונת המיטה).
- `labels/`: התיוגים המדויקים (`labels.json`), טבלת תיוגים (`labels.csv`) וטבלה לכל זוג פריימים של כל הסריקות (`per_pair_results.csv`).
- `masks/`: מסכות הגוף שבהן נעשה שימוש בכל המספרים (אפשר להריץ בלי YOLO).
- `results/`: כל ה-CSV, הגרפים וה-README של הניסויים.
- `reproduce.sh`: מריץ מחדש את כל עשר הסריקות מהמסכות השמורות. צריך `SCANS_DIR` עם תיקיות הסריקה.

## השיטה בקצרה
1. לכל זוג פריימים סמוכים (i-1, i) מחשבים את תנועת המצלמה מזווית ה-encoder ומודל הקשת (שישה פרמטרים).
2. נקודה סטטית בפריים A חייבת להופיע בפריים B על קו אפיפולרי. פיקסל ב-A נותן רק כיוון (קרן), הקרן נראית ב-B כקו ישר, והעומק קובע רק איפה על הקו (פרלקסה). לכן פרלקסה לא נמדדת כתנועה.
3. נקודות גוף: מסכת סגמנטציה (YOLOv8m, איחוד כל זיהויי ה-person), חתוכה עם אזור הגלאי, מעקב KLT עם בדיקה קדימה-אחורה של 0.1 פיקסל.
4. ציון הזוג: חציון השארית של k שכנות, והערך הגבוה ביותר בתמונה. **k=16 ברירת המחדל** (היה 30, והוחלט להשאיר). סף 0.5 פיקסל (כ-1.1 מ"מ במישור המיטה). התרעה רק בחלון ההקרנה, ו**עם `--persistence 2` (ברירת מחדל מאוקטובר 2026)**: נדרשים שני זוגות חשודים ברצף, כך שזוג בודד לא מתריע (ההתרעה מגיעה זוג אחד, כ-0.2 שניות, מאוחר יותר).
5. "אין מספיק נקודות גוף" (פחות מ-k, כלומר 16 כברירת מחדל ו-30 קודם) הוא מצב נפרד מ"אין תנועה". עם k=16 כמה זוגות בחולצה חלקה מקבלים ציון (עצירת נשימה: 22 מתוך 66 במקום 19), מפחות נקודות, ולכן רועש יותר. בדיקת הרקע (`geometry_state`) מאבחנת בלבד, והיא לא מאומתת.
6. זוג הוא שני פריימים רצופים (i-1, i) והציון נרשם בפריים i. "מעבר 54→55" הוא זוג 55.

## התיוגים (זוגות)

| scan | what | exposure window | moving pairs | confirmed no motion | other labels |
|---|---|---|---|---|---|
| A30 | Volunteer, right leg moves | 44-110 | 55-64, 68-69 | 65-67 | approach motion 9-24 (outside window) |
| A44 | Volunteer, left knee raised and moved sideways | 45-113 | 56-57, 59-61, 63-68, 70-72, 75-76, 80, 83-85 | 58, 62, 69, 73-74, 77-78, 81-82, 90 | - |
| A08 | Volunteer, legs, right knee moves to the right | 59-125 | 74-87 | 73, 88, 115-117 | - |
| A12 | Volunteer, knee, small rotational motion | 49-115 | 57-61 | 56, 62-63, 66 | - |
| A26 | Small hand motion (3-5 mm) | 50-116 | 59-62, 64-68 | 63, 69 | - |
| A28_1 | Phantom-free chest scan, large chest motion | 50-115 | - | - | labelled 63-86 (pauses not checked); suspects 106-110 not verified |
| A07 | Volunteer, legs, no motion | 47-112 | - | - | static control: no motion in the whole window |
| A11 | Volunteer, knee, no motion | 47-113 | - | - | static control: no motion in the whole window |
| legs_static | Volunteer, both legs, static | 74-139 | - | - | static control: no motion in the whole window |
| A27 | Volunteer V03, chest, breath hold (SCAN_LABEL: expected NO MOTION) | 59-125 | - | - | static control: no motion in the whole window |
| VC01_bh | Volunteer, chest, breath hold | 49-114 | - | - | static control: no motion in the whole window |

מה שמסרת לכל סריקה (בתרגום, גם ב-`labels/labels.json`):

- **A30** (`arc22_office_20260907_151756`): Motion from transition 54->55 to 68->69 (pairs 55-69); an earlier motion from 8->9 to 23->24, before the arc reached the start angle (outside the exposure window). Later confirmed: in 65-67 there really was a pause.
- **A44** (`arc22_office_20260907_152109`): Motion from 55->56 to 71->72 (pairs 56-72), then frames 74-76 (pairs 75-76), then frames 79-85 (pairs 80-85). Later confirmed pauses: 57->58, 61->62, 68->69, 72->73, 73->74, 76->77, 77->78, 80->81, 81->82 (pairs 58, 62, 69, 73, 74, 77, 78, 81, 82). Pair 67 is NOT a pause (slight blur at the knee). No motion between 89 and 90 (pair 90).
- **A08** (`arc22_office_20260907_125020`): Motion starts at transition 73->74 (small) and ends after 86->87. No motion 72->73, none 87->88, none around 116. (First stated as ending at 85->86, corrected to 86->87.)
- **A12** (`arc22_office_20260907_125615`): Motion starts at transition 56->57 and ends at 60->61. Confirmed: no motion 65->66; the range 57-61 matches.
- **A26** (`arc22_office_20260907_142049`): Motion starts at transition 58->59 and ends at 67->68 (pairs 59-68), about nine moving pairs; no motion 62->63 and 68->69, small motion in all other pairs of the range.
- **A28_1** (`arc22_office_20260907_151502`): Significant motion from frame 63 to 85 (first message); later the labelled range was given as 63-86 and used as pairs 63-86. Pauses inside it were not checked. Suspects at 106-110 are NOT verified motion.
- **A07** (`arc22_office_20260907_124742`): No motion.
- **A11** (`arc22_office_20260907_125440`): No motion.
- **legs_static** (`arc22_office_20260830_142447_volunteer_both_legs_manual_normal_static_repea`): No motion during the scan. The legs moved at HOME before the arc started (pairs 3-8, outside the window).
- **A27** (`arc22_office_20260907_150841`): Breath hold maintained throughout the complete active sweep; expected class NO MOTION.
- **VC01_bh** (`arc22_office_20260830_130408_volunteer_chest_manual_breath_hold_post`): Breath hold; no deliberate motion.

## דיוק (k=16, סף 0.5 פיקסל, חלון ההקרנה)

| scan | window (pairs) | measurable k=16 / k=30 | moving pairs flagged k=16 | moving flagged k=30 | confirmed no-motion flagged k=16 / k=30 | other in-window pairs flagged (k=16) | noise median / max (k=16) |
|---|---|---|---|---|---|---|---|
| A30 | 44-110 (67) | 67 / 67 | 12 of 12 | 12 of 12 | 0 / 0 of 3 | - | 0.11 / 0.47 |
| A44 | 45-113 (69) | 69 / 69 | 20 of 20 | 17 of 20 | 1 / 1 of 10 | [79] | 0.16 / 1.18 |
| A08 | 59-125 (67) | 67 / 67 | 14 of 14 | 14 of 14 | 0 / 0 of 5 | - | 0.12 / 0.40 |
| A12 | 49-115 (67) | 67 / 67 | 5 of 5 | 5 of 5 | 1 / 1 of 4 | - | 0.09 / 0.55 |
| A26 | 50-116 (67) | 67 / 67 | 4 of 9 | 3 of 9 | 0 / 0 of 2 | - | 0.06 / 0.25 |
| A28_1 | 50-115 (66) | 66 / 65 | 24 of 24 labelled (pauses not checked) | 23 of 24 labelled | - | [87, 106, 107, 108, 109, 110] | 0.16 / 0.53 |
| A07 | 47-112 (66) | 66 / 66 | - | - | - | - | 0.09 / 0.29 |
| A11 | 47-113 (67) | 67 / 67 | - | - | - | - | 0.07 / 0.15 |
| legs_static | 74-139 (66) | 66 / 66 | - | - | - | - | 0.15 / 0.31 |
| A27 | 59-125 (67) | 67 / 67 | - | - | - | - | 0.11 / 0.28 |
| VC01_bh | 49-114 (66) | 22 / 19 | - | - | - | - | 0.10 / 0.23 |

Moving pairs (confirmed by the labeller): k=16 flags 55 of 60, k=30 flags 51 of 60. Confirmed no-motion pairs flagged: k=16 2 of 24, k=30 2 of 24.

- תנועה גדולה (חזה) גבוהה פי 10 עד 100 מהרקע. תנועת ברך הצידה (A08): 14 מתוך 14. סיבוב קטן של ברך (A12): 5 מתוך 5.
- A30 ו-A44: כל העצירות שאישרת שקטות. ההחמצות האמיתיות היחידות הן A44 67, 70, 71, קבוצה קטנה של 10–15 נקודות שחציון של 30 שכנות מחק. עם k=16 הן נתפסות.
- תנועת יד זעירה (A26): 4 מתוך 9 זוגות זזים. זה גבול הרגישות בזמן סיבוב.
- בקרות סטטיות (רגליים, A07, A11, עצירת נשימה): אין התרעות, הציון המקסימלי 0.25 פיקסל.
- התרעות שווא: שתיים בכ-510 זוגות (A44 זוג 90 ו-A12 זוג 66, 0.52–0.55 פיקסל). בסריקה של 66 זוגות יש כ-25% סיכוי להתרעה גבולית אחת. דרישה לשני זוגות חשודים ברצף (`--persistence 2`, ההחלטה: ברירת מחדל) מסירה את שתיהן, במחיר עיכוב של זוג אחד (כ-0.2 שניות). התרעות עם persistence 2 ב-`results/k16_p2_2026_10/`.
- k=16 מול k=30: ב-60 זוגות זזים מאושרים, 55 מול 51, באותן התרעות שווא. על הסריקות שלא שימשו לבחירה (A08, A12, A26): 23 מול 22 מתוך 28.

## מה השיטה לא רואה
תנועה לאורך הגוף (ראש-רגליים) ותנועה לכיוון המצלמה (הרמה מהמיטה) נשארות על הקו האפיפולרי, ולכן כמעט בלתי נראות בזוג אחד. תנועה ימינה-שמאלה של המטופל נראית היטב. נשימת חזה היא בעיקר הרמה, ולכן "אין התרעה" שם לא אומר "אין תנועה". זו תוצאה גאומטרית של המודל, לא מדידה על מטופל.

## מגבלות
בדיקת הרקע לא מאומתת. בחולצה חלקה רק 22 (עצירת נשימה, עם k=16; 19 עם k=30) ו-28 (נשימה רגילה, k=30) מתוך 66 זוגות מדידים. רגישות 0.14 מ"מ אפשרית רק כשהקשת עומדת, ולא נבדקה על תנועה אמיתית. k ו-persistence הוחלטו על עשר סריקות. התיוג של A28_1 לא נבדק לעצירות, והחשדות 106–110 לא מאומתים.

## הרצה
```
pip install -r code/requirements.txt
cd code
python3 scripts/evaluate_scan.py --scan <תיקיית סריקה> --calib data/CalibrationResult_arc22.json --gantry data/gantry_arc22.json \
   --detector-mask data/roi_arc22_calibrated.png --roi-fixed --bed data/bed_home_arc22.png --detect masked_abs --body-fb-max 0.1 \
   --guard bed --guard-action mark --body-masks ../masks/<סריקה> --out out/<שם>.csv --plot out/<שם>.png
```
פרמטרים עיקריים: `--cluster-k 8|16|30`, `--threshold`, `--persistence`, `--all-phases`, `--from-csv`. טבלת הסקריפטים והעמודות ב-`README.md`.

## עוד בחבילה
- A27 (מתנדב V03, חזה, עצירת נשימה) כבקרה שלילית: 67 מתוך 67 זוגות עם ציון, בלי התרעות (חציון 0.11, מקסימום 0.28).
- השוואת מסכות YOLO למסכות הידניות (A07, A11, A27) ב-`results/mask_comparison_2026_10/`: בתוך אזור הגלאי כיסוי 1.00, IoU 0.99 בחזה, 0.68 ב-A07 (עודף על המיטה בין הרגליים). הציון של אותו זוג סטטי זהה.
- כלי סימון מסכה בדפדפן: `code/tools/mask_annotator.html`, ושלושה פריימים לסימון הבא ב-`results/annotation_frames/` (A44 60, A30 58, A08 78).

## מה פתוח
סריקה קלינית עם עצירות בזמן ההקרנה; הפחתת שינויי בהירות לחולצה חלקה; בדיקת רקע חדשה; בדיקת עצירות בתיוג של A28_1; זמן אמת (סגמנטציה על GPU).
