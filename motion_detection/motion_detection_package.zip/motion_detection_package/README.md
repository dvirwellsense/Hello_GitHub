# Patient-motion detection from the ARC22 gantry camera: full package

Deck (English, 33 slides): https://claude.ai/artifact/F8khHgMArTEGyJ4Ub6o1Ho
Git branch with all commits: `claude/patient-motion-detection-f6b2d2` in `dvirwellsense/Hello_GitHub` (`motion_detection/`).
A Hebrew summary is in `README.he.md`. Everything below was produced between September and October 2026 from the scans you provided.

## 1. Contents of this package

```
README.md, README.he.md      this file and its Hebrew summary
reproduce.sh                 re-runs the evaluation of all eleven scans from the saved body masks (no segmentation needed)
code/
  tools/                     mask_annotator.html: browser tool to draw body masks (add/subtract polygons)
  motion/                    the library (calibration, gantry model, tracking, masks, rigidity score, ROI, bed)
  scripts/                   evaluate_scan.py (main CLI), plot_scan.py, cluster_size_study.py, cluster_size_report.py,
                             blind_motion_check.py, fit_gantry.py, ... (see section 9)
  data/                      CalibrationResult_arc22.json, gantry_arc22.json, roi_arc22_calibrated.png, bed_home_arc22.png
  requirements.txt
  README_project_he.md       the original (older, Hebrew) project README, kept for reference
labels/
  labels.json                the exact labels of every scan (single source of truth), with your original statements
  labels.csv                 one row per labelled pair
  per_pair_results.csv       every pair of every scan: label status, k=16 and k=30 scores, flags, states
masks/<scan>/body_<frame>.png   the exact body masks used for every reported number (union of YOLOv8m person detections)
results/                     all CSVs, plots and per-experiment READMEs (see section 8)
```

The raw scan images are not included (you have them). Folder names of the scans are listed in section 4.

## 2. Goal and clinical rules

Detect patient motion during an X-ray arc scan from a fisheye RGB camera mounted on the arc (1280x720, about 4-6 fps,
arc range about +-16.5 degrees). The encoder angle of every frame is known; synchronisation between the image and the angle
is slightly uncertain. Real time is preferred; post-scan detection is also useful.

Rules given for the evaluation:
- Only motion **above the detector** matters (calibrated mask `data/roi_arc22_calibrated.png`, bounding box 360,216,324x332 px).
- Motion during the approach from HOME and during the return does not matter (no radiation then). Alarms exist only inside the
  **exposure window**: from the last frame of the start dwell to the first frame of the end dwell. Motion outside it is measured and plotted, but never alarms.
- In clinical mode the arc stops during exposure, so frames at the same angle are compared directly.
- A reconstruction pixel is 0.14 mm.
- Natural breathing is **not** a negative control. Do not tune new thresholds without being asked.

## 3. The method

**Rigidity check (epipolar).** For every pair of consecutive frames (a, b), a static point seen at pixel p in frame a must appear in
frame b on the epipolar line of p. A pixel in frame a gives only a ray (a direction, no distance); that ray is a straight line in the
undistorted image of frame b, and the unknown depth decides only where along that line the point lands (parallax). So parallax
is never measured as motion. The distance of a tracked point from its line is its residual.

1. **Undistortion.** Points (not images) are undistorted with the ARC22 calibration. The frame is resized to 640x360 and padded by 127 px each side (894x360),
   rational model with 8 coefficients. `cv2.undistortPoints` is run with 100 iterations / 1e-10 (the default 5 iterations left errors of up to 3 px near the image border).
   One pixel of the corrected half-resolution image is about 2.2 mm at the bed plane.
2. **Camera motion.** `data/gantry_arc22.json`: a camera rigidly attached to the arc rotating about a fixed axis (6 parameters + sign), fitted once on the static phantom
   scan. The image is assumed to be taken at 90% between `angle_before` and `angle_after` (sync factor 0.9). The essential matrix of a pair follows from the two angles.
3. **Where to look.** A person-segmentation body mask (YOLOv8m-seg on the image rotated by 90 degrees; union of all person detections with confidence >= 0.1,
   `--seg-select union --seg-conf 0.1`), eroded by 21 px, intersected with the fixed detector region.
4. **Tracking.** Corners are detected inside the mask (`--detect masked_abs`, absolute quality threshold) and tracked with pyramidal KLT (21x21 window). A point is kept only if the
   forward-backward error is below 0.1 px (`--body-fb-max 0.1`). This configuration is called **E3**.
5. **Score.** For every point, the median residual of its k nearest points; the pair score is the maximum over points. **k=16 is the default since the cluster-size
   study in section 6.4** (it was 30 before; `--cluster-k 30` reproduces the old numbers). The median cancels isolated tracking noise, the maximum still finds a small
   region that moved. If fewer than k body points exist (16 with the default, 30 before) the pair gets no score (`NO_BODY_DATA`): "not enough information" is kept separate from "no motion". With k=16, a few more pairs on smooth shirts are scored (breath hold: 22 of 66 pairs instead of 19; A28_1 pair 82), from fewer points, so those scores are noisier.
6. **Decision.** Score > 0.5 px (about 1.1 mm at the bed plane) is `SUSPECT`. Alarm only inside the exposure window, with **persistence 2** (default since October 2026): an alarm needs two consecutive suspected pairs, so an isolated single pair never alarms (the alarm comes one pair, about 0.2 s, later). The per-pair state `motion_state` is unaffected.
   When the arc is stopped (same angle) the pair is compared directly: a coherent displacement of a body region, after removing the common background shift, with a 0.5 mm threshold.
7. **Two separate judgements per pair.** `motion_state`: SUSPECT / NO_MOTION / NO_BODY_DATA. `geometry_state` (background check on bed points near the ROI, **diagnostic only**,
   see limitations): VERIFIED / UNRELIABLE / BG_MISSING / NOT_CHECKED. A suspected motion whose background is missing is shown, not dropped.
   Results are always saved before any filtering (`candidate_raw`, all scores).

**Pair convention.** A pair is two consecutive frames (i-1, i); its score is recorded at frame i (column `frame`). A label "transition 54->55" is pair 55.
"12 of 15 detected" means 15 pairs lie inside the labelled range and 12 of them were flagged.

## 4. Scans and labels

Scan folders (all under `arc22_office_`): see `labels/labels.json` (`folder`). Pair numbers below are **pairs** (second frame).

| scan | what | exposure window | moving pairs | confirmed no motion | other labels |
|---|---|---|---|---|---|
| A30 | Volunteer, right leg moves | 44-110 | 55-64, 68-69 | 65-67 | approach motion 9-24 (outside window) |
| A44 | Volunteer, left knee raised and moved sideways | 45-113 | 56-57, 59-61, 63-68, 70-72, 75-76, 80, 83-85 | 58, 62, 69, 73-74, 77-78, 81-82, 90 | - |
| A08 | Volunteer, legs, right knee moves to the right | 59-125 | 74-87 | 73, 88, 115-117 | - |
| A12 | Volunteer, knee, small rotational motion | 49-115 | 57-61 | 56, 62-63, 66 | - |
| A26 | Small hand motion (3-5 mm) | 50-116 | 59-62, 64-68 | 63, 69 | - |
| A28_1 | Phantom-free chest scan, large chest motion | 50-115 | - | - | labelled 63-86 (pauses not checked); suspects 106-110 not verified |
| A07 | Volunteer, legs, no motion | 47-112 | - | - | static control: no motion in the whole window |
| A11 | Volunteer, knee, no motion | 47-113 | - | - | static control: no motion in the whole window |
| legs_static | Volunteer, both legs, static | 74-139 | - | - | static control: no motion in the whole window |
| A27 | Volunteer V03, chest, breath hold (SCAN_LABEL: expected NO MOTION) | 59-125 | - | - | static control: no motion in the whole window |
| VC01_bh | Volunteer, chest, breath hold | 49-114 | - | - | static control: no motion in the whole window |

**What you told me for each scan** (translated; in `labels/labels.json` as `statement`). If any of this does not match your notes, `labels.json` is the one place to correct, and
`scripts/cluster_size_report.py` and the per-pair CSV are then regenerated from it:

- **A30** (`arc22_office_20260907_151756`): Motion from transition 54->55 to 68->69 (pairs 55-69); an earlier motion from 8->9 to 23->24, before the arc reached the start angle (outside the exposure window). Later confirmed: in 65-67 there really was a pause.
- **A44** (`arc22_office_20260907_152109`): Motion from 55->56 to 71->72 (pairs 56-72), then frames 74-76 (pairs 75-76), then frames 79-85 (pairs 80-85). Later confirmed pauses: 57->58, 61->62, 68->69, 72->73, 73->74, 76->77, 77->78, 80->81, 81->82 (pairs 58, 62, 69, 73, 74, 77, 78, 81, 82). Pair 67 is NOT a pause (slight blur at the knee). No motion between 89 and 90 (pair 90).
- **A08** (`arc22_office_20260907_125020`): Motion starts at transition 73->74 (small) and ends after 86->87. No motion 72->73, none 87->88, none around 116. (First stated as ending at 85->86, corrected to 86->87.)
- **A12** (`arc22_office_20260907_125615`): Motion starts at transition 56->57 and ends at 60->61. Confirmed: no motion 65->66; the range 57-61 matches.
- **A26** (`arc22_office_20260907_142049`): Motion starts at transition 58->59 and ends at 67->68 (pairs 59-68), about nine moving pairs; no motion 62->63 and 68->69, small motion in all other pairs of the range.
- **A28_1** (`arc22_office_20260907_151502`): Significant motion from frame 63 to 85 (first message); later the labelled range was given as 63-86 and used as pairs 63-86. Pauses inside it were not checked. Suspects at 106-110 are NOT verified motion.
- **A07** (`arc22_office_20260907_124742`): No motion.
- **A11** (`arc22_office_20260907_125440`): No motion.
- **legs_static** (`arc22_office_20260830_142447_volunteer_both_legs_manual_normal_static_repea`): No motion during the scan. The legs moved at HOME before the arc started (pairs 3-8, outside the window).
- **A27** (`arc22_office_20260907_150841`): Breath hold maintained throughout the complete active sweep; expected class NO MOTION.
- **VC01_bh** (`arc22_office_20260830_130408_volunteer_chest_manual_breath_hold_post`): Breath hold; no deliberate motion.

Notes:
- "Confirmed no motion" are pairs where you saw no motion (pauses inside long labels, quiet neighbours, A44 pair 90, A12 pair 66, A08 around 116).
- "Moving" pairs are the labelled pairs minus the confirmed pauses. A28_1 has not been checked for pauses, and its suspects 106-110 are not verified motion.
- Other scans used earlier but not in the table: VC01 natural breathing (not a negative control), the phantom scan (gantry fit and noise level), plus the scans sent as frame snapshots.

## 5. Window, units and settings

- Exposure window per scan: see the table above (pairs). Pairs outside it are measured and plotted, never alarmed.
- Scores are in pixels of the undistorted half-resolution image. Threshold 0.5 px.
- Same-angle (arc stopped) noise on the phantom: about 0.02 mm; a "static" volunteer moves 0.17-0.25 mm there. The 0.14 mm requirement is only reachable when the arc is stopped,
  and has not been tested on real motion (no clinical-mode scan yet).
- Run settings of every result are stored next to each CSV as `<name>.settings.json` (command line, all parameters, commit, library versions, weight and calibration hashes).

## 6. Accuracy results

All numbers: E3 with the union masks, calibrated ROI fixed, threshold 0.5 px, k=16 unless stated. The per-pair flags below are "score > 0.5 px" (persistence 1). Alarms with the default persistence 2 are in `results/k16_p2_2026_10/*.csv`. Source: `results/k16_2026_10/*.csv` and `labels/per_pair_results.csv`.

### 6.1 Per scan, exposure window

| scan | window (pairs) | measurable k=16 / k=30 | moving pairs flagged k=16 | moving flagged k=30 | confirmed no-motion flagged k=16 / k=30 | other in-window pairs flagged (k=16) | noise median / max (k=16) |
|---|---|---|---|---|---|---|---|
| A30 | 44-110 (67) | 67 / 67 | 12 of 12 | 12 of 12 | 0 / 0 of 3 | - | 0.11 / 0.47 |
| A44 | 45-113 (69) | 69 / 69 | 20 of 20 | 17 of 20 | 1 / 1 of 10 | [79] | 0.16 / 1.18 |
| A08 | 59-125 (67) | 67 / 67 | 14 of 14 | 14 of 14 | 0 / 0 of 5 | - | 0.12 / 0.40 |
| A12 | 49-115 (67) | 67 / 67 | 5 of 5 | 5 of 5 | 1 / 1 of 4 | - | 0.09 / 0.55 |
| A26 | 50-116 (67) | 67 / 67 | 4 of 9 | 3 of 9 | 0 / 0 of 2 | - | 0.06 / 0.25 |
| A28_1 | 50-115 (66) | 66 / 65 | 24 of 24 labelled (pauses not checked) | 23 of 24 labelled | - | [87, 106, 107, 108, 109, 110] | 0.16 / 0.53 |
| A07 | 47-112 (66) | 66 / 66 | - | - | - | - | 0.09 / 0.29 |
| A11 | 47-113 (67) | 67 / 67 | - | - | - | - | 0.07 / 0.15 |
| legs_static | 74-139 (66) | 66 / 66 | - | - | - | - | 0.15 / 0.31 |
| A27 | 59-125 (67) | 67 / 67 | - | - | - | - | 0.11 / 0.28 |
| VC01_bh | 49-114 (66) | 22 / 19 | - | - | - | - | 0.10 / 0.23 |

Moving pairs (confirmed by the labeller): k=16 flags 55 of 60, k=30 flags 51 of 60. Confirmed no-motion pairs flagged: k=16 2 of 24, k=30 2 of 24.

Reading: "flagged" means score > 0.5 px inside the window. "Other in-window pairs flagged" are unlabelled/static-control pairs or unverified suspects that raised an alarm.
Noise = median and maximum score of the pairs known or assumed to have no motion (confirmed no-motion, static controls, unlabelled).

Headline results:
- Large motion (chest, A28_1) scores 10-100 times above the background. Sideways knee motion (A08) 0.55-5.0, detected in all 14 pairs. Small knee rotation (A12) detected in 5 of 5.
- Leg motion with pauses (A30, A44): every pair where the labeller saw motion is detected except A44 pairs that need k=16 (see 6.4); every confirmed pause is quiet.
- Tiny hand motion (A26, a few millimetres): only 4 of 9 moving pairs detected (k=16; 3 with k=30). This is the sensitivity limit while the arc sweeps.
- Static controls (legs, A07, A11, breath hold): no alarms; maximum score 0.25 px.
- The method's noise while the arc moves is about 0.1 px (median) and at most about 0.25-0.55 px; the two false alarms are borderline (0.52-0.55 px).

### 6.2 False alarms

Two isolated pairs just above the threshold in about 510 negative pairs: A44 pair 90 (0.52 px) and A12 pair 66 (0.55 px); you confirmed there is no motion in either. With k=16 or k=30 the
chance of at least one such borderline alarm in a 66-pair scan is roughly one in four. Requiring two consecutive suspect pairs removes both (section 6.5).

### 6.3 What the method cannot see (geometry)

On the gantry model, a point displaced by 0.003 (camera-to-axis distance = 1) between two frames one degree apart leaves the epipolar line by:
- patient's left-right (across the epipolar lines, vertical in the image): 1.4 px, clearly visible;
- along the body (head-feet, horizontal in the image): 0.00 px, invisible;
- toward the camera (lift off the bed): 0.00 px, invisible (it looks like parallax).

The arc rotates about an axis running side to side of the patient, so the camera moves along the body. Chest breathing is mostly a lift, so "no alert" while the arc moves does not mean
"no motion". This is a geometric result of the model, not a measurement on a patient. `results/blind_check_2026_10/` splits the displacement of the tracked points of the missed pairs
into across/along components: in the 11 missed pairs of the first analysis the along-line excess is within the noise (the along-line measure has a noise floor of 0.4-2 px, so it is not a proof).

### 6.4 Cluster size k (one-factor study, `results/cluster_size_2026_10/`)

Missed pairs in A30 (65-67) and A44 (58, 62, 69, 81, 82) were pauses you confirmed. The other A44 misses (67, 70, 71) were real motion of a small group (10-15 points on the trouser fold),
smoothed away by the 30-point median: their 8-point scores are 6.5 / 2.1 / 9.0 against 0.22 median and 1.46 maximum on unlabelled pairs. Full output of `scripts/cluster_size_report.py`:

```
ALL scans. negatives: static scans + confirmed pauses + unlabelled pairs more than 2 pairs from any label
k   n_neg  median  p95   max   | moving detected at 0.5 | false alarms at 0.5 | moving above max negative
8   518    0.14   0.41  4.68  | 55/60              | 13/518            | 7/60
12  516    0.11   0.31  0.63  | 55/60              | 4/516            | 54/60
16  512    0.10   0.26  0.55  | 55/60              | 2/512            | 55/60
20  511    0.09   0.23  0.55  | 54/60              | 2/511            | 54/60
30  509    0.08   0.19  0.53  | 51/60              | 2/509            | 50/60
45  506    0.07   0.17  0.50  | 47/60              | 1/506            | 47/60

DEVELOPMENT set (k=16 was chosen here): all scans except A08, A12, A26
k   n_neg  median  p95   max   | moving detected at 0.5 | false alarms at 0.5 | moving above max negative
8   351    0.15   0.37  4.68  | 32/32              | 6/351            | 5/32
12  349    0.12   0.32  0.57  | 32/32              | 2/349            | 32/32
16  345    0.11   0.26  0.55  | 32/32              | 1/345            | 32/32
20  344    0.10   0.23  0.52  | 31/32              | 1/344            | 31/32
30  342    0.09   0.18  0.52  | 29/32              | 1/342            | 28/32
45  339    0.08   0.15  0.49  | 25/32              | 0/339            | 25/32

HELD-OUT: A08, A12, A26 (labelled after k=16 was chosen)
k   n_neg  median  p95   max   | moving detected at 0.5 | false alarms at 0.5 | moving above max negative
8   167    0.11   0.48  1.16  | 23/28              | 7/167            | 16/28
12  167    0.09   0.30  0.63  | 23/28              | 2/167            | 22/28
16  167    0.09   0.25  0.55  | 23/28              | 1/167            | 23/28
20  167    0.08   0.23  0.55  | 23/28              | 1/167            | 23/28
30  167    0.07   0.21  0.53  | 22/28              | 1/167            | 22/28
45  167    0.06   0.21  0.50  | 22/28              | 1/167            | 22/28

A44 pairs 67, 70, 71 (confirmed moving, missed at k=30):
  k=8   [6.48, 2.13, 8.98]
  k=12  [6.37, 2.09, 5.21]
  k=16  [6.26, 1.09, 2.56]
  k=20  [5.61, 1.74, 0.34]
  k=30  [0.19, 0.33, 0.2]
  k=45  [0.14, 0.2, 0.2]

A26 (9 moving pairs: 59-62, 64-68; quiet: 63, 69), score per pair at k=16 and k=30:
  k=16: {58: 0.08, 59: 0.68, 60: 0.68, 61: 0.67, 62: 0.42, 63: 0.19, 64: 0.11, 65: 0.27, 66: 0.22, 67: 0.43, 68: 0.78, 69: 0.25}
  k=30: {58: 0.07, 59: 0.47, 60: 0.63, 61: 0.67, 62: 0.42, 63: 0.18, 64: 0.09, 65: 0.24, 66: 0.19, 67: 0.42, 68: 0.71, 69: 0.21}

Labelled but pauses not checked: A28_1 63-86, pairs above the largest negative of each k
  k=8   12/24
  k=12  24/24
  k=16  24/24
  k=20  24/24
  k=30  23/23
  k=45  21/21

```

Conclusions: k=8 and 12 give false alarms (static legs, a confirmed pause). k=16 detects 55 of 60 confirmed moving pairs, k=30 detects 51, with the same two borderline false alarms.
On the held-out scans (A08, A12, A26: labelled after k=16 was chosen) k=16 detects 23 of 28 and k=30 22 of 28 with one false alarm each; the gain there is a single pair (A26 pair 59).
k=16 became the code default and the owner confirmed keeping it. It was chosen on A30/A44 data it is judged on, so treat it as validated only on three further scans.

### 6.5 Persistence (decided: default 2)

- A44: isolated false alarms with persistence 1: [90]; with persistence 2: none; moving pairs lost with persistence 2: none
- A12: isolated false alarms with persistence 1: [66]; with persistence 2: none; moving pairs lost with persistence 2: none
- A26: isolated false alarms with persistence 1: none; with persistence 2: none; moving pairs lost with persistence 2: [68]

Requiring two consecutive suspect pairs removes both false alarms and keeps every motion segment detected; the price is one pair (about 0.2 s) of latency and isolated one-pair motions
(A26 pair 68). **Decision (October 2026): `--persistence 2` is the default.** Alarm frames with it are in `results/k16_p2_2026_10/` (A44: 57, 60, 61, 64-68, 71, 72, 76, 80, 84, 85; A12: 58-61; A26: 60, 61; A08: 75-87; A30: 56-64, 69; A28_1: 64-87 and 107-110; no alarm in the static controls). Only tested on these scans.

### 6.6 Earlier comparisons

- Static phantom, old 2D alignment against the new method: mean residual 1.32 px against 0.16 px with no motion (eight times lower on the same points).
- `results/experiments_2026_10/`: E0-E3 point-selection experiments (local selection inside body and ROI, absolute quality threshold, forward-backward limit 0.1 px), each changing one component.
- `results/bed_validation_2026_10/`: validation of the bed-point selection. The RANSAC "bed" consensus is **not** the physical bed plane (sticker corners are accepted 0-25% at one frame, 0% at four;
  the chained outline drifts about 6 px per degree; the head is missing from the YOLO mask and is accepted as "bed"). `geometry_state` is therefore diagnostic only.
- `results/background_study_2026_10/`: how local background residuals relate to body residuals (the body score is not normalised by the background).
- `results/legs_A30_A44_2026_10/`: A30 and A44 with the top mask, union mask and global point selection. The union mask removed all `NO_BODY_DATA` pairs on legs (26 and 19 before).
- `results/union_check_2026_10/`: union mask re-run on A28_1, A26, legs, breath hold: identical pair by pair to the top mask.
- Brightness normalisation `I - GaussianBlur(I, sigma=7) + 128` is being tested separately by the team and was not duplicated here.

### 6.7 Body masks against hand-drawn masks (`results/mask_comparison_2026_10/`)

Hand-drawn masks (policy: skin, clothing and worn shoes; no bed or reflections) exist for A07 frame 53, A11 frame 80 and A27 frame 92 (annotation file `human_masks/user_annotations.json`).
Inside the detector ROI the YOLOv8m masks cover everything the human drew (recall 1.00); IoU 0.99 on the chest (A27), 0.89 (A11), 0.68 (A07, where the mask also covers the bed between the legs,
about a third of the ROI). The score of the same static pair is identical with either mask (k=16: 0.09 / 0.07 / 0.09). No moving pair has been tested with a hand-drawn mask yet; that is the open check
(`results/annotation_frames/`, kit `mask_annotation_kit.zip`). A27 (volunteer V03, chest, breath hold) was also run as an extra negative control: 67 of 67 pairs scored, no alarm, noise median 0.11, maximum 0.28.

## 7. Limitations

- The background (bed) check is not validated (section 6.6) and is diagnostic only.
- Smooth shirts: in breath hold only 22 of 66 pairs with k=16 (19 with k=30), and in natural breathing 28 of 66 (k=30), have enough body points; the rest are reported as missing information, not "no motion".
- Directions invisible to the check: along the body and toward the camera (6.3). Breathing is not detected while the arc sweeps.
- Small motions (A26, a few millimetres) sit at the threshold while the arc sweeps. Sub-0.14 mm needs the stopped-arc comparison, untested on real motion.
- Cluster size and persistence were decided on ten scans, partly the same ones; labels of A28_1 were not checked for pauses; suspects 106-110 of A28_1 are unverified.
- The detector region comes from your calibration; the earlier rectangle `280,150,620,375` was only an estimate (used in early results in `results/*.csv`).
- Real time: segmentation takes about 0.6 s per frame on a CPU; everything else is fast enough for 4-6 fps.

## 8. Where each result lives

| folder | content |
|---|---|
| `results/k16_2026_10/` | the final evaluation (k=16) of all ten scans: CSV + settings per scan |
| `results/cluster_size_2026_10/` | the cluster-size study (CSV per scan, `report.txt`, README) |
| `results/blind_check_2026_10/` | along-line vs across-line check, displacement arrows for labelled pairs |
| `results/labelling_2026_10/` | contact sheets of pairs used for labelling A08, A12, A26 |
| `results/volunteers_A07_A12_2026_10/` | A07, A08, A11, A12 (E3u, k=30 CSVs, plots, README with the labels) |
| `results/legs_A30_A44_2026_10/` | A30 and A44 (E0, E3 and E3u) |
| `results/k16_p2_2026_10/` | the same results with the decision rule re-applied with persistence 2 (alarm columns) |
| `results/a27_2026_10/`, `results/mask_comparison_2026_10/` | A27 as an extra static control; YOLO masks against the hand-drawn masks (A07, A11, A27) |
| `results/annotation_frames/`, `code/tools/mask_annotator.html` | the browser mask-annotation tool and the three frames to annotate next (A44 60, A30 58, A08 78) |
| `results/union_check_2026_10/` | union-mask re-run on the earlier scans |
| `results/experiments_2026_10/`, `background_study_2026_10/`, `bed_validation_2026_10/` | earlier experiments (Hebrew READMEs) |
| `results/presentation_figs/` | the plots used in the deck |
| `results/*.csv` | the first runs (September, old estimate of the detector region) |

CSV columns (one row per pair): `frame`, `phase`, `exposure`, `angle`, `dangle`, `n_body`, `epi_enc_cl` (k=8), `epi_enc_cl16`, `epi_enc_cl30`, `epi_enc_med`, `static_cl` (stopped arc),
`motion_state`, `geometry_state`, `candidate_raw`, `alarm_confirmed`, `alarm_any`, `label`, plus the background statistics (`n_bed`, `epi_bed`, ...).
`labels/per_pair_results.csv` is the simplest table to start from.

## 9. Code and how to run

```
pip install -r code/requirements.txt          # numpy scipy opencv matplotlib ultralytics (tested: python 3.11, numpy 2.4, scipy 1.17, opencv 5.0, matplotlib 3.11, ultralytics 8.4)
cd code
python3 scripts/evaluate_scan.py --scan <scan_folder> --calib data/CalibrationResult_arc22.json --gantry data/gantry_arc22.json \
   --detector-mask data/roi_arc22_calibrated.png --roi-fixed --bed data/bed_home_arc22.png --detect masked_abs --body-fb-max 0.1 \
   --guard bed --guard-action mark --seg-select union --seg-conf 0.1 --out out/<name>.csv --plot out/<name>.png --label 55-64
```
Add `--body-masks ../masks/<scan>` to use the saved masks instead of running YOLOv8 (`reproduce.sh` does this for all eleven scans; set `SCANS_DIR` to the folder holding the scan folders).
Main options: `--cluster-k 8|16|30` (default 16), `--threshold` (0.5 px), `--persistence` (2), `--static-threshold-mm` (0.5), `--all-phases`, `--from-csv` (re-apply the decision rule to an existing CSV),
`--detect global|masked|masked_abs`, `--guard legacy|time|bg|bed|none`, `--sync 0.9`.

| script | purpose |
|---|---|
| `scripts/evaluate_scan.py` | main CLI: every pair of a scan -> CSV (+ settings.json, plot, masks) |
| `scripts/plot_scan.py` | two-panel figure (angle by phase, log score with labelled bands) |
| `scripts/cluster_size_study.py`, `cluster_size_report.py` | the cluster-size study and its summary (labels are defined at the top of the report script) |
| `scripts/blind_motion_check.py` | across/along-line split of the displacement, displacement-arrow pictures |
| `scripts/fit_gantry.py` | refit the gantry model from a static scan |
| `scripts/inspect_cluster.py`, `show_residuals.py` | show the points behind a score |
| `scripts/bed_validation.py`, `background_study.py`, `bed_plane_model.py`, `bed_anchor_check.py` | background and bed-plane studies |
| `scripts/run_all.sh`, `run_experiments.sh`, `run_background_study.sh` | earlier reproduction scripts |

Library (`code/motion/`): `calib.py` (calibration and iterative undistortion), `scan.py` (angles, phases, exposure window), `gantry.py` (gantry model, essential matrix),
`masks.py` (YOLOv8 segmentation, union option), `tracking.py` (KLT with forward-backward check), `rigidity.py` (the scores, `evaluate_pair`), `roi.py`, `bed.py`.

## 10. Related work in another chat (reported by the owner, October 2026)

A parallel project (`arc_sequential_motion_analysis_v1`, threshold 0.7, own detector) found: a hand-drawn body mask removed a static false alarm (A09 pair 105->106: 1.848 -> 0.067) and kept the chest motion (A28_1 67->68: 14.9);
uniform brightness changes hardly affect tracking, spatial ones lose measurements (A44 tracking error 0.08 -> 0.27 px, synthetic) and the tested corrections lost measurements on real images (static chest 32 -> 4 -> 15 of 32);
a consistency filter on tracks was rejected (8 static windows 8 -> 6 alarms, one real detection lost); sticker-corner and shirt-edge localisation tests were inconclusive for the calibration;
a candidate automatic mask model (LR-ASPP MobileNetV3, 48-72 ms per image on CPU with random weights) is being considered (weight licence to be checked; five hand masks are not enough to train from scratch).
Licence note: the segmentation used here is Ultralytics YOLOv8, whose licence is AGPL-3.0 (commercial licence otherwise); verify before any commercial use.

## 11. Open questions and suggested next steps

1. A scan in clinical mode, with stops during exposure, to test the stopped-arc comparison on real motion and the 0.14 mm goal.
2. Persistence 2 is now the default; confirm it on new scans, and test a mask drawn by hand on a moving pair.
3. Reduce brightness changes before tracking (smooth shirts), tested by the team.
4. A new background check (exclude the head, validate against the sticker corners) before `geometry_state` is trusted.
5. Check pauses in the A28_1 label and the suspects 106-110.
6. Real time: segmentation on a GPU or every few frames.
