#!/bin/sh
# Re-run the k=16 evaluation of all ten scans from the saved body masks (no YOLO needed).
# usage: SCANS_DIR=/path/to/folder/with/scan/folders sh reproduce.sh
set -e
: "${SCANS_DIR:?set SCANS_DIR to the folder containing the scan folders}"
HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE/code"
mkdir -p ../results/rerun
run() { # name folder [label args]
  n=$1; d=$2; shift 2
  python3 scripts/evaluate_scan.py --scan "$SCANS_DIR/$d" --calib data/CalibrationResult_arc22.json --gantry data/gantry_arc22.json \
    --detector-mask data/roi_arc22_calibrated.png --roi-fixed --bed data/bed_home_arc22.png --detect masked_abs --body-fb-max 0.1 \
    --guard bed --guard-action mark --body-masks "../masks/$n" "$@" --out "../results/rerun/$n.csv" --plot "../results/rerun/$n.png"
}
run A30 arc22_office_20260907_151756 --label 55-64 --label 68-69 --label 9-24
run A44 arc22_office_20260907_152109 --label 56-57 --label 59-61 --label 63-68 --label 70-72 --label 75-76 --label 80-80 --label 83-85
run A08 arc22_office_20260907_125020 --label 74-87
run A12 arc22_office_20260907_125615 --label 57-61
run A07 arc22_office_20260907_124742
run A11 arc22_office_20260907_125440
run A26 arc22_office_20260907_142049 --label 59-62 --label 64-68
run A28_1 arc22_office_20260907_151502 --label 63-86
run legs_static arc22_office_20260830_142447_volunteer_both_legs_manual_normal_static_repea
run A27 arc22_office_20260907_150841
run VC01_bh arc22_office_20260830_130408_volunteer_chest_manual_breath_hold_post
echo "done: ../results/rerun/"
