# Patient motion detection, ARC22 arc camera: frozen release 2026-10-26

Everything needed to re-run the detector locally on the same 11 scans and compare with this version: code, run
settings, labels, the body masks that were used, per-pair results and the timing runs. The scan images are not
included; put the original scan folders next to it (names below). Hebrew version: `README.he.md`.

Nothing was tuned for this release. All runs were made from one clean commit and reproduce the earlier results exactly.

## Contents

| Folder | What |
|---|---|
| `code/` | `motion_detection/` at commit **1c05c62** (`1c05c62c460943b99585707c59f6ac14d07c8314`) (`git archive`), see `code/REVISION` |
| `env/` | versions (`versions_main.txt`, `versions_mediapipe.txt`), pinned requirements, hardware, sha256 of the weights |
| `labels/` | `labels_per_pair.csv` (every pair: label and label type), `statements.md` (what the labeller said, per scan) |
| `masks/` | body masks used (eroded, `body_<frame>.png`, white = body): `yolov8m_union` (main), `yolov8n640_every4`, `mediapipe_selfie`, `mediapipe_multiclass` |
| `runs/` | every run, CSV + `.settings.json` (command, all parameters, commit, versions): `regular`, `combined` (+ plots), `mediapipe_*`, `yolov8n640_every4`, `realtime_*`, `injection`, `chain_injection`, `logs` |
| `tables/` | `per_pair_results.csv` (item 2), `comparison_*` (item 3), `masks_per_scan.*` (item 6), `realtime_timing*` (item 7) |
| `docs/` | `calibration_vs_test.md` (item 4), `injection_method.md` (item 5) |
| `licenses/` | MediaPipe licence and model cards, Ultralytics licence, `SOURCES.md` (item 6) |
| `reproduce.sh` | runs everything and compares with `runs/` |

## 1. Reproduction

**Commits.** All runs in `runs/` were produced by commit **2735e69** (`2735e69ed5c61c4f841c7de6082b64bb6896e826`) of
`dvirwellsense/Hello_GitHub`, branch `claude/patient-motion-detection-f6b2d2`, with a clean tree (`git_commit` and
`git_dirty: false` in every `runs/*/*.settings.json`). `code/` is commit **1c05c62** (`1c05c62c460943b99585707c59f6ac14d07c8314`); the difference to 2735e69 is only in
`scripts/release_tables.py` (table formatting), `scripts/chain_check_report.py` (the report keeps only chains inside the
exposure window when it reads full runs) and the new `scripts/verify_release.py`; nothing that computes a score. The tables
and the two injection reports were made with the code in `code/`.

**Dependencies** (`env/versions_main.txt`, `env/requirements_pinned.txt`): Python 3.11.15, numpy 2.4.6, scipy 1.17.1,
opencv-python 5.0.0.93, torch 2.14.1 (CPU), torchvision 0.29.1, ultralytics 8.4.170, matplotlib 3.11.2. The MediaPipe masks
were made in a separate venv (`env/versions_mediapipe.txt`: mediapipe 1.1.1). Weights are not included: `yolov8m-seg.pt`,
`yolov8n-seg.pt` (ultralytics downloads them by name), MediaPipe `.tflite` from the URLs in `licenses/SOURCES.md`; check
`env/weights_sha256.txt`. With the saved masks no segmentation is run, so the weights are only needed for the live real-time
runs and to regenerate masks.

**Scans** (folder names as recorded; put them in one folder `$SCANS`):

| scan | folder | scan | folder |
|---|---|---|---|
| A30 | arc22_office_20260907_151756 | A07 | arc22_office_20260907_124742 |
| A44 | arc22_office_20260907_152109 | A11 | arc22_office_20260907_125440 |
| A08 | arc22_office_20260907_125020 | legs_static | arc22_office_20260830_142447_volunteer_both_legs_manual_normal_static_repea |
| A12 | arc22_office_20260907_125615 | VC01_bh | arc22_office_20260830_130408_volunteer_chest_manual_breath_hold_post |
| A26 | arc22_office_20260907_142049 | A27 | arc22_office_20260907_150841 |
| A28_1 | arc22_office_20260907_151502 | | |

**Exact commands** (from `code/`; `M=../masks`, `S=$SCANS`; example A30; all scans: `bash scripts/release_runs.sh $S $M out`):

```
COMMON="--calib data/CalibrationResult_arc22.json --gantry data/gantry_arc22.json --detector-mask data/roi_arc22_calibrated.png \
  --roi-fixed --bed data/bed_home_arc22.png --detect masked_abs --body-fb-max 0.1 --guard bed --guard-action mark"
mkdir -p out/regular out/combined out/realtime_saved_masks out/realtime_v8n640_every4   # evaluate_scan.py does not create the folder

# regular detector (adjacent pairs only; k=16, 0.5 px, persistence 2)
python3 scripts/evaluate_scan.py --scan $S/arc22_office_20260907_151756 $COMMON --body-masks $M/yolov8m_union/A30 --chain-L 0 --out out/regular/A30.csv

# detector with the chained L=4 second check (= the defaults: --chain-L 4 --chain-threshold 1.2)
python3 scripts/evaluate_scan.py --scan $S/arc22_office_20260907_151756 $COMMON --body-masks $M/yolov8m_union/A30 --out out/combined/A30.csv --plot out/combined/A30.png

# real-time version (motion/realtime.py), saved masks; exposure flags taken from the combined run
python3 scripts/realtime_run.py --scan $S/arc22_office_20260907_151756 --csv out/combined/A30.csv --body-masks $M/yolov8m_union/A30 --out out/realtime_saved_masks/A30.csv

# real-time version with the mask computed live: YOLOv8n, 640 px, every 4 frames
python3 scripts/realtime_run.py --scan $S/arc22_office_20260907_151756 --csv out/combined/A30.csv --seg-weights yolov8n-seg.pt --seg-imgsz 640 --mask-every 4 --out out/realtime_v8n640_every4/A30.csv

# compare a local run with this release (scores to 1e-9 px, flags exactly; timing not compared)
python3 scripts/verify_release.py ../runs out
```

`--guard bed --guard-action mark` only adds diagnostic columns; it does not change any alarm. Regenerating the YOLOv8m
masks: `evaluate_scan.py ... --seg-select union --seg-conf 0.1 --save-masks <dir>` (YOLOv8m-seg, 960 px, image rotated
90 deg clockwise, eroded 21 px); MediaPipe: `scripts/make_masks_permissive.py` in the MediaPipe venv. Regenerated masks
may differ slightly from the saved ones on other hardware; use the saved masks to compare the detector itself.

**Checks done for this release.** `regular` = `alarm_adjacent` of `combined` on every pair; `combined` reproduces
`results/k16_chain_2026_10` and `regular` reproduces `results/k16_p2_2026_10` exactly (scores and alarms); the real-time
version reproduces `combined` exactly on all 11 scans (max score difference 0, no alarm mismatch), with the saved masks and
with the live YOLOv8n mask (whose masks are pixel-identical to `masks/yolov8n640_every4`).

## 2. Results per pair: `tables/per_pair_results.csv`

One row per pair a -> b (all phases, 1774 pairs; the exposure window has 735). Columns:
`scan, frame_a, frame_b, in_exposure_window, phase, same_angle, angle_b_deg`;
labels: `label` (motion / no_motion / motion_range / motion_outside_window / no_motion_scan / suspect_unverified / unlabelled),
`label_type` (**exact** = confirmed for this pair, **general_range** = stated for a range or the whole scan, not pair by pair,
**unknown** = nothing stated or not verified), `negative_in_counts` (counted as a negative, in the window only);
regular check: `adj_score_kind, adj_score_px, adj_n_points, adj_measurable, adj_not_measurable_reason, adj_suspect`
(score above threshold, before persistence), `adj_suspect_in_window, alarm_regular` (after persistence 2);
second check: `chain_frame_a` (= frame b-4), `chain_score_px, chain_n_points, chain_measurable, chain_not_measurable_reason,
chain_eligible, chain_not_eligible_reason, chain_above_threshold, chain_suspect` (eligible and above 1.2 px, before
persistence), `alarm_chain`; and `alarm_final` (regular or chained).

Label definitions: `code/scripts/labels_2026_10.py` and `labels/statements.md`. In the window: 60 exact motion pairs,
24 exact no-motion pairs, 24 general-range motion pairs (A28_1 63-86), 332 pairs of static scans (general range),
5 unverified suspects (A28_1 106-110), 290 unlabelled.

Not measurable in the window: regular check 44 of 735 pairs (38 with fewer than 8 body points, 6 with fewer than 16; all in
VC01_bh 69-112, the smooth shirt above the detector); second check 45 pairs with fewer than 16 points after the chained
tracking and 33 pairs not eligible (the chain reaches outside the window: the first 3 pairs of each window). Unmeasurable
pairs are never counted as "no motion".

## 3. Same sample: regular detector vs regular + L=4 (`tables/comparison_*`)

Same 11 scans, same YOLOv8m union masks, same labels, exposure window only.

| | regular | regular + L=4 |
|---|---|---|
| exact motion pairs with an alarm | 43 / 60 | 48 / 60 |
| exact motion pairs above threshold (before persistence) | 55 / 60 | (same regular score) |
| negatives with an alarm (623 negatives) | 0 | 15, all within 3 pairs after labelled motion (see below) |
| negatives with an alarm and no labelled motion in the chain | 0 | 0 |
| static scans (A07, A11, legs_static, VC01_bh, A27) with any alarm | none | none |

Per scan (motion pairs with alarm, regular -> combined): A30 10 -> 10 of 12, A44 14 -> 17 of 20, A08 13 -> 13 of 14,
A12 4 -> 4 of 5, A26 2 -> 4 of 9. A28_1 (general range 63-86): alarm frames 64-87 and 107-110 with the regular detector; the combined one adds 88 and 112.

**Real motions missed before and found now.**
- Episodes as stated by the labeller (A30 55-69, A44 56-72 / 75-76 / 80-85, A08 74-87, A12 57-61, A26 59-68,
  A28_1 63-86): all were already alarmed by the regular detector, with the same first alarm frame. The chain found no
  episode that was missed before.
- Segments of consecutive motion pairs: one segment had no regular alarm, **A26 64-68**; the combined detector alarms at
  pair 64. But the chain of pair 64 runs from frame 60 and also spans motion pairs 61-62 of the previous segment, so this
  alarm **cannot be attributed to segment 64-68 alone**.
- Earlier alarm by one pair on segments the regular detector also alarmed: A44 59-61 (59 vs 60), 63-68 (63 vs 64),
  83-85 (83 vs 84). There the adjacent score was already above threshold; the regular alarm waited for persistence.
- Motion pairs whose adjacent score was below threshold and that are now alarmed: A26 62 and A26 64.

**Alarm frames added by the chain (28), separately** (`tables/comparison_alarms_added_by_chain.csv`): 5 on exact motion
pairs without a regular alarm (above); 22 after or between motion, where the chain still spans labelled motion: 13 of them
on pairs the labeller confirmed as no motion (A30 65-67, A44 58, 62, 77, 78, 81, 82, A08 88, A12 62, 63, A26 63) and 9 on
unlabelled pairs right after motion (A30 70-72, A44 79, 86, 87, A12 64, A26 70, A28_1 88); 1 on A28_1 112, whose chain spans
the unverified suspects 109-110. The alarm therefore lasts up to 3 pairs longer after a motion ends. None of the 28 has a
chain without labelled motion or suspects.

**A16 was never received or analysed.** A26 is included above (small hand motion, 3-5 mm; 4 of 9 motion pairs above the
adjacent threshold, 5 missed: 62, 64-67).

## 4. Calibration vs test: `docs/calibration_vs_test.md`

- 0.5 px (adjacent pairs) was set on 2026-10-01 on A28_1, A26, legs_static, VC01 (breath hold and natural breathing) and
  the phantom: between the largest static score (0.36 px) and the A26 hand motion (0.54-0.60 px). A30, A44, A07, A08,
  A11, A12 and A27 came later.
- k=16 was chosen on A30, A44, A28_1, A07, A11, legs_static, VC01_bh; A08, A12, A26 were labelled afterwards (held out).
- Persistence 2 and the second check's 1.2 px were chosen after looking at **all** scans of this release (1.2 px from the
  noise of A07, A11, legs_static, A27 and the phantom, the injections on those four, and the counts on all 11 scans).
- **There is no independent test of the final configuration.** All numbers in sections 2-3 are in-sample. The nearest to
  independent: A08 and A12 for 0.5 px with k=16 (persistence 1), and A27 for persistence 2. A new set of scans, labelled
  before anyone looks at the scores, is needed.

## 5. Synthetic injection: `docs/injection_method.md`, `runs/injection`, `runs/chain_injection`

Translation of a body region in the image (disc r40 / r80 or the whole body; soft 2 px edge), in undistorted coordinates,
by size_mm x 0.448 px, at a set angle to the epipolar line; only the second frame (adjacent) or the frames after i-4
(chained) are changed; points come from the unchanged first frame and its unchanged mask, tracking and score are
recomputed. mm are at the bed-plane scale, so they overstate the real displacement at the body surface (conservative).
The counts are **suspect pairs** (score above threshold, before persistence); the alarm with persistence 2 was not
simulated.

The chain report's line "static scans + phantom" covers the static scans only (the phantom scan is not part of this release; with it the maximum was 1.32 px, results/chain4_2026_10).

**Adjacent pairs, threshold 0.5 px, k=16** (134 pairs of A07, A11, legs_static, A27; control without injection: median 0.10 px, max 0.29 px). Share of pairs that become suspect:

| region | angle to the line | 0.25 mm | 0.5 mm | 0.75 mm | 1 mm | 1.5 mm | 2 mm | 3 mm | 5 mm |
|---|---|---|---|---|---|---|---|---|---|
| r40 | 0 deg | 0.00 | 0.00 | 0.00 | 0.08 | 0.88 | 0.89 | 0.90 | 0.88 |
| r40 | 30 deg | 0.00 | 0.00 | 0.00 | 0.01 | 0.85 | 0.89 | 0.88 | 0.88 |
| r40 | 60 deg | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.10 | 0.88 | 0.87 |
| r40 | 90 deg | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| r80 | 0 deg | 0.00 | 0.00 | 0.00 | 0.37 | 1.00 | 1.00 | 1.00 | 1.00 |
| r80 | 30 deg | 0.00 | 0.00 | 0.00 | 0.04 | 0.99 | 1.00 | 1.00 | 1.00 |
| r80 | 60 deg | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.37 | 1.00 | 1.00 |
| r80 | 90 deg | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| body | 0 deg | 0.00 | 0.00 | 0.01 | 0.82 | 1.00 | 1.00 | 1.00 | 1.00 |
| body | 30 deg | 0.00 | 0.00 | 0.00 | 0.18 | 1.00 | 1.00 | 1.00 | 1.00 |
| body | 60 deg | 0.00 | 0.00 | 0.00 | 0.00 | 0.01 | 0.87 | 1.00 | 1.00 |
| body | 90 deg | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

**Chained L=4, threshold 1.2 px** (128 chains; control median 0.29 px, max 1.18 px). Share of chains that become suspect:

| region | angle | drift 0.25 mm/frame | drift 0.5 mm/frame | drift 0.75 mm/frame | drift 1 mm/frame | step 1 mm | step 2 mm | step 3 mm | step 4 mm | step 5 mm |
|---|---|---|---|---|---|---|---|---|---|---|
| r80 | 0 deg | 0.00 | 0.03 | 0.97 | 0.99 | 0.00 | 0.03 | 0.97 | 0.98 | 0.98 |
| r80 | 60 deg | 0.00 | 0.00 | 0.00 | 0.02 | 0.00 | 0.00 | 0.00 | 0.03 | 0.44 |
| body | 0 deg | 0.00 | 0.21 | 1.00 | 1.00 | 0.00 | 0.24 | 1.00 | 1.00 | 1.00 |
| body | 60 deg | 0.00 | 0.00 | 0.04 | 0.17 | 0.00 | 0.00 | 0.03 | 0.19 | 0.97 |

Small region on little texture: A27 (chest, ~300 body points) misses r40 motion in about half of the pairs even at 5 mm (see runs/injection/report.txt). Full reports: runs/injection/report.txt, runs/chain_injection/report.txt.

## 6. MediaPipe masks: `licenses/SOURCES.md`, `tables/masks_per_scan.*`

| model | file and URL | licence (source) |
|---|---|---|
| Selfie segmentation (general, 256x256) | `selfie_segmenter.tflite`, sha256 191ac952…658b, https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite | Apache 2.0: model card "Model Card MediaPipe Selfie Segmentation" (May 6, 2021), https://storage.googleapis.com/mediapipe-assets/Model%20Card%20MediaPipe%20Selfie%20Segmentation.pdf |
| Multiclass selfie segmentation (256x256) | `selfie_multiclass_256x256.tflite`, sha256 c6748b12…e0e0, https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_multiclass_256x256/float32/latest/selfie_multiclass_256x256.tflite | Apache 2.0: model card "Model Card Multiclass Segmentation" (May 10, 2023), https://storage.googleapis.com/mediapipe-assets/Model%20Card%20Multiclass%20Segmentation.pdf |
| framework | mediapipe 1.1.1 (pip) | Apache 2.0: https://github.com/google-ai-edge/mediapipe/blob/master/LICENSE |

Copies of the model cards and licence are in `licenses/`. The `.tflite` files carry no licence text; the model card is the
source for the weights. YOLOv8 (ultralytics 8.4.170, weights `yolov8m-seg.pt` / `yolov8n-seg.pt`) is AGPL-3.0.
Mask: image rotated 90 deg clockwise, selfie = confidence > 0.5, multiclass = every class except background, back-rotated,
eroded 21 px; then the same detector (defaults, regular + L=4).

| scan | YOLOv8m: measurable / motion above thr. / alarms | selfie: measurable, missing pairs | selfie: motion above thr. | multiclass: measurable, missing pairs | multiclass: motion above thr. |
|---|---|---|---|---|---|
| A30 | 67/67 / 12/12 / 10 | 67/67 | 12/12 | 67/67 | 12/12 |
| A44 | 69/69 / 20/20 / 17 | 69/69 | 20/20 | 69/69 | 20/20 |
| A08 | 67/67 / 14/14 / 13 | 66/67, missing 124 | 14/14 | 67/67 | 14/14 |
| A12 | 67/67 / 5/5 / 4 | 35/67, missing 49-61, 63-64, 66-78, 110-111, 114-115 | 0/5; alarms lost 58-64 | 64/67, missing 88, 99, 101 | 5/5 |
| A26 | 67/67 / 4/9 / 4 | 67/67 | 4/9 | 43/67, missing 50-71, 77, 82 | 0/9; alarms lost 60-64, 70 |
| A28_1 | 66/66 / - / - | 66/66 | - | 66/66 | - |
| A07 | 66/66 / - / - | 63/66, missing 108, 110, 112 | - | 66/66 | - |
| A11 | 67/67 / - / - | 28/67, missing 47-59, 62, 64, 66, 70, 80, 82, 88-89, 93, 95, 98-113 | - | 64/67, missing 90, 94, 96 | - |
| legs_static | 66/66 / - / - | 66/66 | - | 66/66 | - |
| VC01_bh | 22/66 (missing 69-112) / - / - | 22/66, missing 69-112 | - | 10/66, missing 57-112 | - |
| A27 | 67/67 / - / - | 67/67 | - | 67/67 | - |

Totals (window): motion pairs above threshold YOLOv8m 55/60, selfie 50/60, multiclass 51/60; motion pairs with an alarm
48 / 44 / 44. **A26 with multiclass: 24 of 67 window pairs not measurable (50-71, 77, 82), so all 9 motion pairs are
missing (not "no motion") and the alarms 60-64, 70 are lost.** Selfie fails on A12 (35 of 67 measurable, motion 0/5) and A11
(28 of 67). No mask gives an alarm on a static scan.

## 7. Real time: `tables/realtime_timing_all.md`, `tables/realtime_timing_per_scan.md`

**Hardware**: cloud container, Intel Xeon @ 2.10 GHz, 4 cores (1 thread per core, AVX-512), 15 GiB RAM, no GPU. torch
4 threads, OpenCV `getNumThreads()` = 1, OMP_NUM_THREADS unset; one process, frames one after the other, nothing else
running. **Per frame**: decode = JPEG decoding from memory (the file is read before the clock starts, as from the
camera), mask = YOLO + erosion (only on the frames where it is computed), monitor = the decision (both checks); total =
their sum. The first 3 frames of each scan (warm-up) are excluded and reported separately. Budget: the camera delivers a
frame every ~0.25 s (median interval).

| configuration (1752 frames, 11 scans) | total mean | total p95 | total max | frames > 250 ms |
|---|---|---|---|---|
| saved masks (no segmentation timed) | 84 ms | 145 ms | 405 ms | 1 |
| YOLOv8n 640, every 4 frames: all frames | 148 ms | 291 ms | 455 ms | 201 (11%) |
| — frames where the mask is computed (443) | 199 ms | 325 ms | 455 ms | |
| — frames that reuse the previous mask (1309) | 131 ms | 265 ms | 409 ms | |
| YOLOv8m 960, every frame | 692 ms | 855 ms | 1155 ms | 1752 (all) |

Parts: decode ~4 ms; YOLOv8n 640 mask 66 ms mean (p95 84, max 118); YOLOv8m 960 mask 563 ms mean; the decision 77 ms mean
with saved masks (p95 136, max 398). Warm-up frames: up to 159 ms (saved masks), 338 ms (YOLOv8n), 941 ms (YOLOv8m).

**This corrects what was said before** ("YOLOv8n every 4 frames stays within 0.25 s"). On this machine it does not on
the scans with many body points: A07, A08 and legs_static have means of 218-224 ms and 50-62 frames each above 250 ms.
The decision itself is slower when YOLO runs in the same process (mean 128 ms vs 77 ms with saved masks, for about the same
number of points), probably because the torch threads keep the cores busy after each inference; this was not tested.
Options not tried (no tuning in this release): segmentation in a separate process, fewer torch threads, the target machine.
The real-time outputs are identical to the offline detector in every case.
