# Which scans were used to choose what (calibration vs test)

Dates and commits are from the git history of `motion_detection/` (branch `claude/patient-motion-detection-f6b2d2`).

| Choice | When (commit) | Scans available / looked at when it was chosen | Scans that came later and did not influence it |
|---|---|---|---|
| Threshold 0.5 px, adjacent pairs (then on the 30-point cluster score, ~1.1 mm at the bed plane); 0.5 mm when the gantry is stopped | 2026-10-01 (`11944a8`; before that the default was 2.0 px) | A28_1 (chest motion), A26 (small hand motion), legs_static, VC01 breath hold, VC01 natural breathing, chest phantom. Placed between the largest static score (0.36 px) and the hand motion of A26 (0.54-0.60 px), as written in the README of that commit | A30, A44 (2026-10-06), A07, A08, A11, A12 (2026-10-06), A27 (2026-10-22) |
| Point selection E3 (`--detect masked_abs --body-fb-max 0.1`), bed guard (diagnostic only, `--guard-action mark`) | 2026-10-05 (`5afa344`, `60b412f`, `200198d`) | A28_1, A26, legs_static, VC01 | A30, A44, A07, A08, A11, A12, A27 |
| Union body mask (`--seg-select union --seg-conf 0.1`) | 2026-10-06 (`8dc3a19`) | A30, A44 (legs-only views where the top mask failed) and the earlier scans | A07, A08, A11, A12 were evaluated with it the same day (`607b466`), A27 later |
| Cluster size k=16 (was 30) | 2026-10-06/07 (`6760ba4`, `73d3794`) | Development: A30, A44, A28_1, A07, A11, legs_static, VC01_bh | Held out: A08, A12, A26 were labelled after k=16 was chosen (results/cluster_size_2026_10). A26 had been used for the 0.5 px threshold, so for "0.5 px with k=16" only A08 and A12 are independent; A27 came later |
| Persistence 2 (was 1) | 2026-10-22 (`de4fc0f`) | All 10 scans then available (it removes the two isolated false suspects A44 90 and A12 66, confirmed no motion by the labeller, and loses one isolated moving pair, A26 68) | A27 only (a static control) |
| Second check L=4 and its threshold 1.2 px | 2026-10-25 (`830c9f3`; study results/chain4_2026_10) | Noise of the static scans A07, A11, legs_static, A27 and the phantom; synthetic injection on A07, A11, legs_static, A27; and the counts on ALL 11 real scans at 0.8-1.6 px (1.0 px gave 8 alarms on negatives, 1.2 px none) | None |

**There is no independent test set for the final configuration.** Persistence 2 and the 1.2 px threshold were chosen
after looking at all the scans in this release, so every number of the combined detector on these 11 scans is in-sample.
The closest to an independent check is A08 and A12 for the adjacent-pair score at 0.5 px with k=16 and persistence 1
(labelled after k=16 was chosen, not used for 0.5 px), and A27 for persistence 2 (one static control). A new set of
scans, recorded and labelled before anyone looks at the scores, is needed to test the frozen version.
