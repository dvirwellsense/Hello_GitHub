# Synthetic motion injection: how it was done

Code: `scripts/inject_motion.py` (adjacent pairs) and `scripts/chain_check.py inject` (chained L=4). Runs: `runs/injection/`,
`runs/chain_injection/` (phase `injection` of `scripts/release_runs.sh`). Scans: the static controls A07, A11, legs_static,
A27 only. Pairs: every second pair that is inside the exposure window, with the gantry moving, and measurable in the real
run (adjacent) / whose whole chain is inside the window with the gantry moving (chained).

## What is moved
- **Region**: `r40` / `r80` = a disc of radius 40 / 80 raw pixels (1280x720 image) around a body point above the detector,
  drawn at random (seeded with the frame index, so the same point every run) from the pixels of (body mask of frame a)
  AND (detector region); the disc is intersected with the body extent (the saved, eroded mask dilated back by 21 px).
  `body` = the whole body extent. At the bed-plane scale 40 / 80 raw px are about 9 / 18 cm across.
- **Edges**: the region is a 0/1 map smoothed with a Gaussian of sigma 2 px; weights below 0.01 are set to 0. Inside the
  region the full displacement is applied, over the ~4 px wide edge a partial one (the image is stretched there), outside
  nothing. The edge is therefore soft, not a cut.
- **Displacement**: a pure 2-D translation in undistorted image coordinates (the coordinates of the score), of
  size_mm x 0.4479 px (calibration `m_fPixelsInMM`), mapped back pixel by pixel to the raw fisheye image (backward map,
  `cv2.remap`, bilinear, border reflect). Direction: angle to the epipolar line of the gantry model through the region
  centre (0 deg = across the line, fully visible to the score; 90 deg = along it, invisible by construction). The line is
  taken through the centre's position in frame b instead of a (a few px apart).
- **Adjacent pairs**: only frame b of the pair is re-sampled. **Chained L=4**: frames i-3 .. i are re-sampled; drift
  `v` = frame i-4+k shifted by k*v (k = 1..4); step `s` = frames i-2 .. i shifted by s (a step in the middle of the chain,
  then held).

## What is recomputed and what is not
- Frame a (adjacent) / frame i-4 (chained) and its body mask are untouched, so the same body points are detected as
  in the real run; the tracking is recomputed on the modified frames and the score is recomputed.
- No mask is recomputed (the mask of frame a is used, as in the real pipeline), the detector region is fixed.
- Control (no injection) reproduces the real run exactly (max difference 0 px), see the reports.

## Assumptions in the conversion to mm
- 0.4479 px per mm is the scale of the bed plane. The body surface is higher, closer to the camera, so 1 mm there spans
  more pixels: a stated "1 mm" (0.448 px) corresponds to less than 1 mm of real motion at the body surface. The stated mm
  are therefore conservative (the real sensitivity in mm at the body surface is somewhat better); the height of the
  surface was not measured, so this is not corrected.
- The motion is a rigid translation in the image only: no rotation, no out-of-plane (3-D) motion, no deformation, no
  motion blur, no change of shading. The direction is defined in the image relative to the epipolar line, not in patient
  coordinates (patient left-right / head-feet / up).

## Suspect pair vs alarm
- The injection reports are **per pair**: a pair counts as detected when its score is above the threshold (a *suspect
  pair*, before persistence). An unmeasurable pair counts as missed.
- The alarm needs `--persistence 2` consecutive suspect pairs. This was **not simulated**: each injected pair is isolated.
  For a motion that lasts at least two pairs with each pair above threshold, the alarm follows the second pair; a motion
  that ends within one frame interval gives one suspect adjacent pair and no alarm from the regular check (the chained
  check then sees it in up to four consecutive chains).
