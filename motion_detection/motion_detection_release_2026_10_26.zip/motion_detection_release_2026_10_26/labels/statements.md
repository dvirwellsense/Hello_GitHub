# What the labeller stated, per scan

A pair is named by its target frame b (pair b-1 -> b). The label of every pair is in labels_per_pair.csv; the rules are in code/scripts/labels_2026_10.py. Scan A16 was never received or analysed.

| scan | folder | what | motion (exact) | no motion (exact) | general range | unverified | statement |
|---|---|---|---|---|---|---|---|
| A30 | arc22_office_20260907_151756 | Volunteer, right leg moves | 55-64, 68-69 | 65-67 | motion 9-24 outside the window | - | Motion from transition 54->55 to 68->69 (pairs 55-69); an earlier motion from 8->9 to 23->24, before the arc reached the start angle (outside the exposure window). Later confirmed: 65-67 is a pause. |
| A44 | arc22_office_20260907_152109 | Volunteer, left knee raised and moved sideways | 56-57, 59-61, 63-68, 70-72, 75-76, 80, 83-85 | 58, 62, 69, 73-74, 77-78, 81-82, 90 | - | - | Motion 55->56 to 71->72, 74->76, 79->85. Confirmed pauses 57->58, 61->62, 68->69, 72->73, 73->74, 76->77, 77->78, 80->81, 81->82. Pair 67 is not a pause (blur at the knee). No motion 89->90. |
| A08 | arc22_office_20260907_125020 | Volunteer, legs, right knee moves to the right | 74-87 | 73, 88, 115-117 | - | - | Motion from 73->74 (small) to 86->87. No motion 72->73, 87->88, around 116. |
| A12 | arc22_office_20260907_125615 | Volunteer, knee, small rotational motion | 57-61 | 56, 62-63, 66 | - | - | Motion from 56->57 to 60->61. No motion 65->66; 55->56, 61->62, 62->63 confirmed quiet. |
| A26 | arc22_office_20260907_142049 | Small hand motion (3-5 mm) | 59-62, 64-68 | 63, 69 | - | - | Motion from 58->59 to 67->68; no motion 62->63 and 68->69, small motion in the other pairs of the range. |
| A28_1 | arc22_office_20260907_151502 | Chest, large motion | - | - | motion 63-86 (pauses not checked) | 106-110 | Significant motion in frames 63-86 (pairs 63-86); pauses inside not checked. Suspects 106-110 not verified. |
| A07 | arc22_office_20260907_124742 | Volunteer, legs, no motion | - | - | whole scan: no motion | - | No motion. |
| A11 | arc22_office_20260907_125440 | Volunteer, knee, no motion | - | - | whole scan: no motion | - | No motion. |
| legs_static | arc22_office_20260830_142447_volunteer_both_legs_manual_normal_static_repea | Volunteer, both legs, static | - | - | motion 3-8 outside the window; whole scan: no motion | - | No motion during the scan; the legs moved at HOME before the arc started (pairs 3-8, outside the window). |
| VC01_bh | arc22_office_20260830_130408_volunteer_chest_manual_breath_hold_post | Volunteer, chest, breath hold | - | - | whole scan: no motion | - | Breath hold; no deliberate motion. |
| A27 | arc22_office_20260907_150841 | Volunteer V03, chest, breath hold | - | - | whole scan: no motion | - | SCAN_LABEL: breath hold maintained throughout the active sweep; expected NO MOTION. |
