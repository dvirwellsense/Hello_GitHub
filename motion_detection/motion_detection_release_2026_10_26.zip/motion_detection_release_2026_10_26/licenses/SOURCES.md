# Model and licence sources (checked 2026-10-26)

| Model file (sha256) | Downloaded from | Licence of the weights | Licence of the framework |
|---|---|---|---|
| `selfie_segmenter.tflite` (191ac952…658b, 249 537 bytes; internal name selfiesegmentation_mlkit-256x256-2021_01_19-v1215) | https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite | Apache License 2.0, per the model card "Model Card MediaPipe Selfie Segmentation" (date May 6, 2021, section LICENSED UNDER), https://storage.googleapis.com/mediapipe-assets/Model%20Card%20MediaPipe%20Selfie%20Segmentation.pdf (copy in this folder) | MediaPipe, Apache License 2.0: https://github.com/google-ai-edge/mediapipe/blob/master/LICENSE (copy: mediapipe_LICENSE_Apache-2.0.txt); pip package mediapipe 1.1.1 |
| `selfie_multiclass_256x256.tflite` (c6748b12…e0e0, 16 371 837 bytes) | https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_multiclass_256x256/float32/latest/selfie_multiclass_256x256.tflite | Apache License 2.0, per the model card "Model Card Multiclass Segmentation" (model date May 10, 2023, section LICENSED UNDER), https://storage.googleapis.com/mediapipe-assets/Model%20Card%20Multiclass%20Segmentation.pdf (copy in this folder) | same |
| `yolov8m-seg.pt` (51fa7e5e…c4f4), `yolov8n-seg.pt` (a7cd8f92…423c) | Ultralytics release assets (downloaded automatically by the ultralytics package) | AGPL-3.0: package metadata of ultralytics 8.4.170 (License: AGPL-3.0; licence file copied as ultralytics_LICENSE_AGPL-3.0.txt). The weights are distributed by Ultralytics under the same terms; Ultralytics offers a separate commercial licence. Check with whoever handles licences | ultralytics 8.4.170, AGPL-3.0 |

The .tflite files themselves carry no licence text (checked with `strings`). The model card is the source of the weights'
licence. The MediaPipe page that lists these models (ai.google.dev/edge/mediapipe/solutions/vision/image_segmenter)
could not be reached from the container (blocked by the network policy), so the link from the page to the model cards
was not re-checked; the model card PDFs were downloaded from the URLs above.
The weights are not included in the ZIP (licence and size); download them from the URLs and check the sha256.
