#!/bin/bash
# Re-run the release on your scans and compare with runs/.
#   bash reproduce.sh <scans_dir> [phases]      phases: eval injection realtime tables (default: all)
# <scans_dir>: the 11 scan folders under their original names (README, section 1).
# realtime needs the weights: YOLOV8N=<path to yolov8n-seg.pt> YOLOV8M=<path to yolov8m-seg.pt> bash reproduce.sh ...
# Run "realtime" alone on an idle machine (timing).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE/code"
bash scripts/release_runs.sh "$1" "$HERE/masks" "$HERE/out" "${@:2}"
python3 scripts/verify_release.py "$HERE/runs" "$HERE/out"
