realtime_masks_v8n640/ (the masks computed live by realtime_run.py) is left out: it is pixel-identical to masks/yolov8n640_every4/ (checked for every frame of the 11 scans).
