| scan | frame_b | chain_frame_a | pair_label | label_type | chain_score_px | adj_score_px | adj_suspect | class_ | motion_pairs_in_chain | unverified_in_chain |
|---|---|---|---|---|---|---|---|---|---|---|
| A30 | 65 | 61 | no_motion | exact | 3.6395 | 0.223 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 62-64 | - |
| A30 | 66 | 62 | no_motion | exact | 2.9052 | 0.0918 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 63-64 | - |
| A30 | 67 | 63 | no_motion | exact | 1.9777 | 0.4664 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 64 | - |
| A30 | 70 | 66 | unlabelled | unknown | 1.7709 | 0.0823 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 68-69 | - |
| A30 | 71 | 67 | unlabelled | unknown | 1.497 | 0.3038 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 68-69 | - |
| A30 | 72 | 68 | unlabelled | unknown | 1.3133 | 0.4462 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 69 | - |
| A44 | 58 | 54 | no_motion | exact | 6.4025 | 0.1879 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 56-57 | - |
| A44 | 59 | 55 | motion | exact | 5.0908 | 5.8425 | 1 | motion pair without a regular alarm | 56-57, 59 | - |
| A44 | 62 | 58 | no_motion | exact | 4.3658 | 0.3535 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 59-61 | - |
| A44 | 63 | 59 | motion | exact | 2.7775 | 0.7855 | 1 | motion pair without a regular alarm | 60-61, 63 | - |
| A44 | 77 | 73 | no_motion | exact | 2.0233 | 0.1912 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 75-76 | - |
| A44 | 78 | 74 | no_motion | exact | 1.5236 | 0.2086 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 75-76 | - |
| A44 | 79 | 75 | unlabelled | unknown | 2.4205 | 1.1846 | 1 | alarm continues after / between motion (the chain still spans labelled motion) | 76 | - |
| A44 | 81 | 77 | no_motion | exact | 4.7888 | 0.3002 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 80 | - |
| A44 | 82 | 78 | no_motion | exact | 3.9112 | 0.4081 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 80 | - |
| A44 | 83 | 79 | motion | exact | 3.0814 | 0.8441 | 1 | motion pair without a regular alarm | 80, 83 | - |
| A44 | 86 | 82 | unlabelled | unknown | 2.6017 | 0.1999 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 83-85 | - |
| A44 | 87 | 83 | unlabelled | unknown | 1.8015 | 0.1289 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 84-85 | - |
| A08 | 88 | 84 | no_motion | exact | 3.2377 | 0.3898 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 85-87 | - |
| A12 | 62 | 58 | no_motion | exact | 6.248 | 0.4334 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 59-61 | - |
| A12 | 63 | 59 | no_motion | exact | 3.6023 | 0.4111 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 60-61 | - |
| A12 | 64 | 60 | unlabelled | unknown | 2.0757 | 0.2049 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 61 | - |
| A26 | 62 | 58 | motion | exact | 2.4666 | 0.4207 | 0 | motion pair without a regular alarm | 59-62 | - |
| A26 | 63 | 59 | no_motion | exact | 1.9584 | 0.1854 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 60-62 | - |
| A26 | 64 | 60 | motion | exact | 1.3148 | 0.1088 | 0 | motion pair without a regular alarm | 61-62, 64 | - |
| A26 | 70 | 66 | unlabelled | unknown | 1.3782 | 0.0594 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 67-68 | - |
| A28_1 | 88 | 84 | unlabelled | unknown | 1.8241 | 0.1828 | 0 | alarm continues after / between motion (the chain still spans labelled motion) | 85-86 | - |
| A28_1 | 112 | 108 | unlabelled | unknown | 1.8221 | 0.1693 | 0 | chain spans unverified suspects | - | 109-110 |
