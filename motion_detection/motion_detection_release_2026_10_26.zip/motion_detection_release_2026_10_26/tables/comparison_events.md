| scan | level | pairs | label_type | detected_regular | first_alarm_regular | detected_combined | first_alarm_combined | newly_detected | note |
|---|---|---|---|---|---|---|---|---|---|
| A30 | episode | 55-69 | exact | 1 | 56 | 1 | 56 | 0 |  |
| A30 | segment | 55-64 | exact | 1 | 56 | 1 | 56 | 0 |  |
| A30 | segment | 68-69 | exact | 1 | 69 | 1 | 69 | 0 |  |
| A44 | episode | 56-72 | exact | 1 | 57 | 1 | 57 | 0 |  |
| A44 | segment | 56-57 | exact | 1 | 57 | 1 | 57 | 0 |  |
| A44 | segment | 59-61 | exact | 1 | 60 | 1 | 59 | 0 |  |
| A44 | segment | 63-68 | exact | 1 | 64 | 1 | 63 | 0 |  |
| A44 | segment | 70-72 | exact | 1 | 71 | 1 | 71 | 0 |  |
| A44 | episode | 75-76 | exact | 1 | 76 | 1 | 76 | 0 |  |
| A44 | episode | 80-85 | exact | 1 | 80 | 1 | 80 | 0 |  |
| A44 | segment | 80-80 | exact | 1 | 80 | 1 | 80 | 0 |  |
| A44 | segment | 83-85 | exact | 1 | 84 | 1 | 83 | 0 |  |
| A08 | episode | 74-87 | exact | 1 | 75 | 1 | 75 | 0 |  |
| A12 | episode | 57-61 | exact | 1 | 58 | 1 | 58 | 0 |  |
| A26 | episode | 59-68 | exact | 1 | 60 | 1 | 60 | 0 |  |
| A26 | segment | 59-62 | exact | 1 | 60 | 1 | 60 | 0 |  |
| A26 | segment | 64-68 | exact | 0 |  | 1 | 64 | 1 | chain i-4 -> i at 64 also spans earlier motion pairs 61-62: cannot be attributed to this segment alone |
| A28_1 | episode | 63-86 | general_range | 1 | 64 | 1 | 64 | 0 |  |
