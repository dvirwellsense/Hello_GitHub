| scan | window_pairs | adj_measurable | chain_measurable_and_eligible | motion_pairs_exact | motion_suspect_regular | motion_alarm_regular | motion_alarm_combined | negatives | negative_suspect_regular | negative_alarm_regular | negative_chain_suspect | negative_alarm_combined | negative_alarm_added_chain_spans_motion | negative_alarm_added_no_motion_in_chain | alarm_frames_regular | alarm_frames_added_by_chain |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A30 | 67 | 67 | 64 | 12 | 12 | 10 | 10 | 51 | 0 | 0 | 4 | 4 | 4 | 0 | 56-64, 69 | 65-67, 70-72 |
| A44 | 69 | 69 | 66 | 20 | 20 | 14 | 17 | 44 | 1 | 0 | 6 | 6 | 6 | 0 | 57, 60-61, 64-68, 71-72, 76, 80, 84-85 | 58-59, 62-63, 77-79, 81-83, 86-87 |
| A08 | 67 | 67 | 64 | 14 | 14 | 13 | 13 | 51 | 0 | 0 | 2 | 1 | 1 | 0 | 75-87 | 88 |
| A12 | 67 | 67 | 64 | 5 | 5 | 4 | 4 | 61 | 1 | 0 | 4 | 3 | 3 | 0 | 58-61 | 62-64 |
| A26 | 67 | 67 | 64 | 9 | 4 | 2 | 4 | 55 | 0 | 0 | 2 | 1 | 1 | 0 | 60-61 | 62-64, 70 |
| A28_1 | 66 | 66 | 61 | 0 | 0 | 0 | 0 | 29 | 0 | 0 | 0 | 0 | 0 | 0 | 64-87, 107-110 | 88, 112 |
| A07 | 66 | 66 | 63 | 0 | 0 | 0 | 0 | 66 | 0 | 0 | 0 | 0 | 0 | 0 | - | - |
| A11 | 67 | 67 | 64 | 0 | 0 | 0 | 0 | 67 | 0 | 0 | 0 | 0 | 0 | 0 | - | - |
| legs_static | 66 | 66 | 63 | 0 | 0 | 0 | 0 | 66 | 0 | 0 | 0 | 0 | 0 | 0 | - | - |
| VC01_bh | 66 | 22 | 20 | 0 | 0 | 0 | 0 | 66 | 0 | 0 | 0 | 0 | 0 | 0 | - | - |
| A27 | 67 | 67 | 64 | 0 | 0 | 0 | 0 | 67 | 0 | 0 | 0 | 0 | 0 | 0 | - | - |
