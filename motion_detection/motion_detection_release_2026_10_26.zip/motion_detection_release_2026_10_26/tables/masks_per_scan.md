| mask | scan | window_pairs | measurable | missing_pairs | missing_pairs_yolov8m | motion_pairs | motion_suspect | motion_missed | motion_alarm_final | negatives | negative_suspect | negative_alarm_final | alarm_frames_lost_vs_yolov8m | alarm_frames_new_vs_yolov8m |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| combined | A30 | 67 | 67 | - | - | 12 | 12 | - | 10 | 51 | 0 | 4 | - | - |
| combined | A44 | 69 | 69 | - | - | 20 | 20 | - | 17 | 44 | 1 | 6 | - | - |
| combined | A08 | 67 | 67 | - | - | 14 | 14 | - | 13 | 51 | 0 | 1 | - | - |
| combined | A12 | 67 | 67 | - | - | 5 | 5 | - | 4 | 61 | 1 | 3 | - | - |
| combined | A26 | 67 | 67 | - | - | 9 | 4 | 62, 64-67 | 4 | 55 | 0 | 1 | - | - |
| combined | A28_1 | 66 | 66 | - | - | 0 | 0 | - | 0 | 29 | 0 | 0 | - | - |
| combined | A07 | 66 | 66 | - | - | 0 | 0 | - | 0 | 66 | 0 | 0 | - | - |
| combined | A11 | 67 | 67 | - | - | 0 | 0 | - | 0 | 67 | 0 | 0 | - | - |
| combined | legs_static | 66 | 66 | - | - | 0 | 0 | - | 0 | 66 | 0 | 0 | - | - |
| combined | VC01_bh | 66 | 22 | 69-112 | 69-112 | 0 | 0 | - | 0 | 66 | 0 | 0 | - | - |
| combined | A27 | 67 | 67 | - | - | 0 | 0 | - | 0 | 67 | 0 | 0 | - | - |
| mediapipe_selfie | A30 | 67 | 67 | - | - | 12 | 12 | - | 10 | 51 | 0 | 4 | - | - |
| mediapipe_selfie | A44 | 69 | 69 | - | - | 20 | 20 | - | 17 | 44 | 1 | 6 | - | - |
| mediapipe_selfie | A08 | 67 | 66 | 124 | - | 14 | 14 | - | 13 | 51 | 0 | 1 | - | - |
| mediapipe_selfie | A12 | 67 | 35 | 49-61, 63-64, 66-78, 110-111, 114-115 | - | 5 | 0 | 57-61 | 0 | 61 | 0 | 0 | 58-64 | - |
| mediapipe_selfie | A26 | 67 | 67 | - | - | 9 | 4 | 62, 64-67 | 4 | 55 | 0 | 1 | - | - |
| mediapipe_selfie | A28_1 | 66 | 66 | - | - | 0 | 0 | - | 0 | 29 | 0 | 0 | - | - |
| mediapipe_selfie | A07 | 66 | 63 | 108, 110, 112 | - | 0 | 0 | - | 0 | 66 | 1 | 0 | - | - |
| mediapipe_selfie | A11 | 67 | 28 | 47-59, 62, 64, 66, 70, 80, 82, 88-89, 93, 95, 98-113 | - | 0 | 0 | - | 0 | 67 | 0 | 0 | - | - |
| mediapipe_selfie | legs_static | 66 | 66 | - | - | 0 | 0 | - | 0 | 66 | 0 | 0 | - | - |
| mediapipe_selfie | VC01_bh | 66 | 22 | 69-112 | 69-112 | 0 | 0 | - | 0 | 66 | 0 | 0 | - | - |
| mediapipe_selfie | A27 | 67 | 67 | - | - | 0 | 0 | - | 0 | 67 | 0 | 0 | - | - |
| mediapipe_multiclass | A30 | 67 | 67 | - | - | 12 | 12 | - | 10 | 51 | 0 | 4 | - | - |
| mediapipe_multiclass | A44 | 69 | 69 | - | - | 20 | 20 | - | 17 | 44 | 1 | 6 | - | - |
| mediapipe_multiclass | A08 | 67 | 67 | - | - | 14 | 14 | - | 13 | 51 | 0 | 1 | - | - |
| mediapipe_multiclass | A12 | 67 | 64 | 88, 99, 101 | - | 5 | 5 | - | 4 | 61 | 0 | 3 | - | - |
| mediapipe_multiclass | A26 | 67 | 43 | 50-71, 77, 82 | - | 9 | 0 | 59-62, 64-68 | 0 | 55 | 0 | 0 | 60-64, 70 | - |
| mediapipe_multiclass | A28_1 | 66 | 66 | - | - | 0 | 0 | - | 0 | 29 | 0 | 0 | - | - |
| mediapipe_multiclass | A07 | 66 | 66 | - | - | 0 | 0 | - | 0 | 66 | 0 | 0 | - | - |
| mediapipe_multiclass | A11 | 67 | 64 | 90, 94, 96 | - | 0 | 0 | - | 0 | 67 | 0 | 0 | - | - |
| mediapipe_multiclass | legs_static | 66 | 66 | - | - | 0 | 0 | - | 0 | 66 | 0 | 0 | - | - |
| mediapipe_multiclass | VC01_bh | 66 | 10 | 57-112 | 69-112 | 0 | 0 | - | 0 | 66 | 0 | 0 | - | - |
| mediapipe_multiclass | A27 | 67 | 67 | - | - | 0 | 0 | - | 0 | 67 | 0 | 0 | - | - |
| yolov8n640_every4 | A30 | 67 | 67 | - | - | 12 | 12 | - | 10 | 51 | 0 | 4 | - | - |
| yolov8n640_every4 | A44 | 69 | 69 | - | - | 20 | 20 | - | 17 | 44 | 1 | 6 | - | - |
| yolov8n640_every4 | A08 | 67 | 67 | - | - | 14 | 14 | - | 13 | 51 | 0 | 1 | - | - |
| yolov8n640_every4 | A12 | 67 | 67 | - | - | 5 | 5 | - | 4 | 61 | 1 | 3 | - | - |
| yolov8n640_every4 | A26 | 67 | 67 | - | - | 9 | 4 | 62, 64-67 | 4 | 55 | 0 | 1 | - | - |
| yolov8n640_every4 | A28_1 | 66 | 66 | - | - | 0 | 0 | - | 0 | 29 | 0 | 0 | - | - |
| yolov8n640_every4 | A07 | 66 | 66 | - | - | 0 | 0 | - | 0 | 66 | 1 | 0 | - | - |
| yolov8n640_every4 | A11 | 67 | 67 | - | - | 0 | 0 | - | 0 | 67 | 0 | 0 | - | - |
| yolov8n640_every4 | legs_static | 66 | 66 | - | - | 0 | 0 | - | 0 | 66 | 0 | 0 | - | - |
| yolov8n640_every4 | VC01_bh | 66 | 22 | 69-112 | 69-112 | 0 | 0 | - | 0 | 66 | 0 | 0 | - | - |
| yolov8n640_every4 | A27 | 67 | 67 | - | - | 0 | 0 | - | 0 | 67 | 0 | 0 | - | - |
