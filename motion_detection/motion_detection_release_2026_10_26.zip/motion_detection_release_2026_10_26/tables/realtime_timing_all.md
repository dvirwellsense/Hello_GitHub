| config | scan | frames | total_mean_ms | total_p95_ms | total_max_ms | total_mask_frames_n | total_mask_frames_mean_ms | total_mask_frames_p95_ms | total_mask_frames_max_ms | total_reuse_frames_mean_ms | total_reuse_frames_p95_ms | total_reuse_frames_max_ms | decode_mean_ms | mask_mean_ms | monitor_mean_ms | monitor_p95_ms | monitor_max_ms | frames_over_250ms | warmup_frames | warmup_total_max_ms |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| realtime_saved_masks | ALL | 1785 | 84.3 | 144.5 | 404.9 | 0 |  |  |  | 84.3 | 144.5 | 404.9 | 4.1 |  | 76.6 | 135.6 | 397.8 | 1 | 33 | 159.1 |
| realtime_v8m960_every1 | ALL | 1785 | 692.4 | 854.9 | 1154.8 | 1752 | 692.4 | 854.9 | 1154.8 |  |  |  | 4.0 | 562.5 | 125.9 | 251.5 | 377.6 | 1752 | 33 | 941.2 |
| realtime_v8n640_every4 | ALL | 1785 | 148.3 | 290.5 | 454.5 | 443 | 199.1 | 325.3 | 454.5 | 131.1 | 264.7 | 409.4 | 3.9 | 66.4 | 127.6 | 260.1 | 403.4 | 201 | 33 | 338.3 |
